(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 47342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 59006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "metadata": () => (/* binding */ metadata),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(85746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31208, 23)), "D:\\NEXT_JS_13\\dreams_AI\\app\\page.tsx"]}]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48514)), "D:\\NEXT_JS_13\\dreams_AI\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70447)), "D:\\NEXT_JS_13\\dreams_AI\\app\\head.tsx"],
        }
      ]
      }.children;
    const metadata = [{
          type: 'layout',
          layer: 0,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 48514)),
          path: "D:\\NEXT_JS_13\\dreams_AI\\app\\layout.tsx",
        },{
          type: 'page',
          layer: 0,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 31208, 23)),
          path: "D:\\NEXT_JS_13\\dreams_AI\\app\\page.tsx",
        },];
    const pages = ["D:\\NEXT_JS_13\\dreams_AI\\app\\page.tsx"];

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 77965:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13996))

/***/ }),

/***/ 31208:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("D:\\NEXT_JS_13\\dreams_AI\\app\\page.tsx");


/***/ }),

/***/ 13996:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var typewriter_effect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99462);
/* harmony import */ var typewriter_effect__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(typewriter_effect__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _app_components_Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(94212);




const axios = __webpack_require__(92981);
const App = ({ mode  })=>{
    const messageEl = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const messageContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const mobileMessageContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const preview =  false || null;
    const previewList = preview && JSON.parse(preview) || null;
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [typing, setTyping] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isPreview, setPreview] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isAdd, setAdd] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [list, setList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            user: true,
            text: "Hi! How Can I Help You?",
            date: new Date().toISOString()
        }
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (previewList) {
            let arrayLength = previewList && previewList.length > 0 && previewList[previewList.length - 1]?.chat;
            if (arrayLength.length > 1) {
                const newChat = {
                    chat: list
                };
                previewList?.push(newChat);
                localStorage.setItem("preview", JSON.stringify(previewList));
            }
        } else if (list.length === 1) {
            const data = [
                {
                    chat: [
                        {
                            user: true,
                            text: "Hi! How Can I Help You?",
                            date: new Date().toISOString()
                        }
                    ]
                }
            ];
            localStorage.setItem("preview", JSON.stringify(data));
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        scrollToBottom();
    });
    const scrollToBottom = ()=>{
        messageEl.current?.scrollIntoView({
            behavior: "smooth"
        });
    };
    const onSubmit = async ()=>{
        setPreview(false);
        const oldPreview = localStorage.getItem("preview");
        let oldPreviewList = JSON.parse(oldPreview);
        if (value !== "") {
            const obj = {
                user: false,
                text: value,
                date: new Date().toISOString()
            };
            setList((prevItems)=>[
                    ...prevItems,
                    obj
                ]);
            setTyping(true);
            let config = {
                method: "post",
                url: "https://apiorthoai.scriptlanes.com/api/doctor/question",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                data: {
                    "question": value
                }
            };
            axios(config).then(async (response)=>{
                setTyping(false);
                const obj1 = {
                    user: true,
                    text: response.data?.text,
                    date: new Date().toISOString()
                };
                setList((prevItems)=>[
                        ...prevItems,
                        obj1
                    ]);
                let arrayLength = oldPreviewList && oldPreviewList.length > 0 && oldPreviewList[oldPreviewList.length - 1]?.chat;
                arrayLength?.push(obj);
                arrayLength?.push(obj1);
                oldPreviewList[oldPreviewList.length - 1].chat = arrayLength;
                localStorage.setItem("preview", JSON.stringify(oldPreviewList));
            }).catch((error)=>{});
            setValue("");
        }
    };
    const convertDate = (value)=>{
        const event = new Date(value);
        return event.toDateString();
    };
    const handleNewChat = async ()=>{
        setPreview(false);
        const chatList = previewList || [];
        let arrayLength = chatList && chatList.length > 0 && chatList[chatList.length - 1]?.chat;
        if (arrayLength.length > 0) {
            const newChat = {
                chat: [
                    {
                        user: true,
                        text: "Hi! How Can I Help You?",
                        date: new Date().toISOString()
                    }
                ]
            };
            chatList?.push(newChat);
            localStorage.setItem("preview", JSON.stringify(chatList));
            await setList(newChat.chat);
            setAdd(!isAdd);
        }
    };
    const handleSetPreviewQuestion = (value)=>{
        setList(value);
        setAdd(!isAdd);
        setPreview(true);
    };
    const resizeObserverDesktop =  false && 0;
    const resizeObserverMobile =  false && 0;
    if (mobileMessageContainerRef?.current)  false && 0;
    if (messageContainerRef?.current)  false && 0;
    const handleDeletePreview = async (tempIndex)=>{
        const check = previewList[tempIndex];
        const tempPreviews = previewList.filter((preview, index)=>index !== tempIndex);
        await localStorage.setItem("preview", JSON.stringify(tempPreviews));
        if (JSON.stringify(check?.chat) == JSON.stringify(list)) {
            const newChat = {
                chat: [
                    {
                        user: true,
                        text: "Hi! How Can I Help You?",
                        date: new Date().toISOString()
                    }
                ]
            };
            tempPreviews?.push(newChat);
            localStorage.setItem("preview", JSON.stringify(tempPreviews));
            await setList(newChat.chat);
        } else setAdd(!isAdd);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                handleNewChat: handleNewChat,
                setList: handleSetPreviewQuestion,
                list: list,
                setAdd: setAdd
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
                className: "flex hidden lg:flex",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex fixed left-0 h-[100svh] w-72 flex-col overflow-y-auto bg-slate-50 pt-8 dark:border-slate-700 dark:bg-slate-900 sm:h-[100vh] sm:w-72",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mx-2 mt-8",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    onClick: ()=>handleNewChat(),
                                    className: "flex w-full gap-x-4 rounded-lg border border-slate-300 p-4 text-left text-sm font-semibold text-secondary transition-colors duration-200 hover:bg-slate-200 focus:outline-none dark:border-slate-700 dark:text-white dark:hover:bg-slate-800",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "h-5 w-5",
                                            viewBox: "0 0 24 24",
                                            strokeWidth: "2",
                                            stroke: "currentColor",
                                            fill: "none",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    stroke: "none",
                                                    d: "M0 0h24v24H0z",
                                                    fill: "none"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    d: "M12 5l0 14"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    d: "M5 12l14 0"
                                                })
                                            ]
                                        }),
                                        "New Chat"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-full space-y-4 overflow-y-auto overflow-x-hidden px-2 py-4",
                                children: previewList && previewList.length > 0 && previewList.map((item, index)=>{
                                    return item?.chat && item.chat?.length > 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        onClick: ()=>{
                                            document.getElementById(`preview-action-${index}`).style.display = "flex";
                                        // handleSetPreviewQuestion(item?.chat)
                                        },
                                        onBlur: ()=>{
                                            document.getElementById(`preview-action-${index}`).style.display = "none";
                                        // handleSetPreviewQuestion(item?.chat)
                                        },
                                        className: "relative flex w-full flex-col gap-y-2 rounded-lg px-3 py-2 text-left transition-colors duration-200",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                className: "flex w-full truncate text-sm font-semibold capitalize text-secondary dark:text-white overflow-x-hidden",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        className: "shrink-0 h-6 w-6 mr-2",
                                                        strokeWidth: "2",
                                                        stroke: "currentColor",
                                                        fill: "none",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                stroke: "none",
                                                                d: "M0 0h24v24H0z",
                                                                fill: "none"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M12 11l0 .01"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M8 11l0 .01"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                d: "M16 11l0 .01"
                                                            })
                                                        ]
                                                    }),
                                                    " ",
                                                    item?.chat[item?.chat?.length - 2]?.text
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-xs text-secondary dark:text-slate-400 ml-8",
                                                children: convertDate(item?.chat[item?.chat?.length - 2]?.date)
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                id: `preview-action-${index}`,
                                                className: "w-20 absolute right-0 inline-block justify-evenly bg-white dark:bg-black hidden",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        className: "pt-1 pl-2",
                                                        onClick: ()=>handleSetPreviewQuestion(item?.chat),
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        width: "30",
                                                        height: "30",
                                                        viewBox: "0 0 42 32",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                            fill: "currentColor",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    d: "M35.652 14.023a.5.5 0 0 0-.303.953C39.257 16.221 41 18.078 41 21c0 2.599-2.371 4.616-3.783 5.588A.5.5 0 0 0 37 27v3.823a7.953 7.953 0 0 1-3.126-2.155a.505.505 0 0 0-.468-.159c-.285.055-.576.133-.871.212c-.51.137-1.036.279-1.535.279c-2.568 0-4.366-.552-6.204-1.903a.5.5 0 0 0-.593.806C26.23 29.393 28.199 30 31 30c.631 0 1.223-.159 1.795-.313c.178-.049.355-.097.53-.138c1.869 1.974 3.983 2.423 4.075 2.441a.495.495 0 0 0 .416-.103A.498.498 0 0 0 38 31.5v-4.239c2.582-1.841 4-4.057 4-6.261c0-3.381-2.017-5.598-6.348-6.977z"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    d: "M33 13.5C33 5.804 25.982 0 16.677 0C7.325 0 0 5.931 0 13.502c0 4.539 3.211 7.791 6 9.759v6.636a.502.502 0 0 0 .705.456c.146-.065 3.559-1.616 6.479-4.809c1.265.235 2.696.461 3.994.461C26.641 26.005 33 20.979 33 13.5zM17.177 25.005c-1.31 0-2.799-.251-4.083-.496a.507.507 0 0 0-.468.159C10.576 26.98 8.167 28.449 7 29.082V23a.5.5 0 0 0-.217-.412C4.145 20.773 1 17.725 1 13.502C1 6.491 7.886 1 16.677 1C25.413 1 32 6.374 32 13.5c0 6.882-5.957 11.505-14.823 11.505z"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    d: "M16.5 11.5c-1.103 0-2 .897-2 2s.897 2 2 2s2-.897 2-2s-.897-2-2-2zm0 3a1.001 1.001 0 0 1 0-2a1.001 1.001 0 0 1 0 2zm7-3c-1.103 0-2 .897-2 2s.897 2 2 2s2-.897 2-2s-.897-2-2-2zm0 3a1.001 1.001 0 0 1 0-2a1.001 1.001 0 0 1 0 2zm-14-2.905c-1.103 0-2 .897-2 2s.897 2 2 2s2-.897 2-2s-.897-2-2-2zm0 3a1.001 1.001 0 0 1 0-2a1.001 1.001 0 0 1 0 2z"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                        onClick: ()=>{
                                                            handleDeletePreview(index);
                                                        },
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        width: "30",
                                                        height: "30",
                                                        viewBox: "0 0 72 72",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                fill: "#FFF",
                                                                d: "M51.76 17H20.153v37.65c0 4.06 3.29 5.62 7.35 5.62H44.41c4.06 0 7.35-1.56 7.35-5.62V17zM31 16v-4h10v4"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                fill: "#9B9B9A",
                                                                d: "M51 37v20.621L48.3 60H33z"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                fill: "#FFF",
                                                                d: "M17 16h38v4H17z"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                fill: "none",
                                                                stroke: "#000",
                                                                "stroke-linecap": "round",
                                                                "stroke-linejoin": "round",
                                                                "stroke-miterlimit": "10",
                                                                "stroke-width": "2",
                                                                d: "M31 16v-4h10v4m10 9v31a4 4 0 0 1-4 4H25a4 4 0 0 1-4-4V25m-4-9h38v4H17zm24 12.25V55M31 28.25V55"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    });
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `flex h-full w-full flex-col`,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                ref: messageContainerRef,
                                className: "flex-1 mb-12 mr-40 ml-[28rem] space-y-6 scroll-smooth hover:scroll-auto overflow-y-auto bg-slate-200 p-4 text-sm leading-6 text-slate-900 dark:bg-slate-900 dark:text-slate-300 sm:text-base sm:leading-7",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "pt-10"
                                    }),
                                    list && list.length > 0 && list.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                item?.user ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            className: "mr-2 h-8 w-8 rounded-full",
                                                            src: "/AI.jpg",
                                                            alt: "img"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex rounded-b-xl text-sm text-secondary dark:text-white rounded-tr-xl bg-sky-chat p-4 dark:bg-slate-chat sm:max-w-md md:max-w-2xl",
                                                            children: !isPreview && index + 1 === list.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((typewriter_effect__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                options: {
                                                                    delay: 20
                                                                },
                                                                onInit: (typewriter)=>{
                                                                    typewriter.typeString(item?.text).pauseFor(2500).callFunction(()=>{
                                                                        messageEl.current?.scrollIntoView({
                                                                            behavior: "smooth"
                                                                        });
                                                                    }).start();
                                                                }
                                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "text-sm text-secondary dark:text-white",
                                                                children: item?.text
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "ml-2 mt-1 flex flex-col-reverse gap-2 text-slate-500 sm:flex-row",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                className: "hover:text-primary text-secondary dark:text-secondary dark:hover:text-primary",
                                                                type: "button",
                                                                onClick: ()=>navigator.clipboard.writeText(item?.text),
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                                    xmlns: "http://www.w3.org/2000/svg",
                                                                    className: "h-5 w-5",
                                                                    viewBox: "0 0 24 24",
                                                                    strokeWidth: "2",
                                                                    stroke: "currentColor",
                                                                    fill: "none",
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                            stroke: "none",
                                                                            d: "M0 0h24v24H0z",
                                                                            fill: "none"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                            d: "M8 8m0 2a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2z"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                            d: "M16 8v-2a2 2 0 0 0 -2 -2h-8a2 2 0 0 0 -2 2v8a2 2 0 0 0 2 2h2"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    ]
                                                }, index) : !item?.user && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex flex-row-reverse items-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            className: "ml-2 h-8 w-8 rounded-full",
                                                            src: "https://dummyimage.com/128x128/354ea1/ffffff&text=G"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex rounded-b-xl rounded-tl-xl bg-sky-chat p-4 dark:bg-slate-chat sm:min-h-0 sm:max-w-md md:max-w-2xl",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "text-sm text-secondary dark:text-white",
                                                                children: item?.text
                                                            })
                                                        })
                                                    ]
                                                }, index),
                                                typing && list.length == index + 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            className: "mr-2 h-8 w-8 rounded-full",
                                                            src: "/AI.jpg",
                                                            alt: "img"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: "/typing.gif",
                                                            className: "w-10",
                                                            alt: "typing"
                                                        })
                                                    ]
                                                }, index)
                                            ]
                                        })),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        ref: messageEl
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mr-40 ml-[28rem] py-2 pb-4 w-[-webkit-fill-available] fixed bottom-0 bg-white dark:bg-black",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "chat-input",
                                        className: "sr-only",
                                        children: "Enter your prompt"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        className: "relative",
                                        onSubmit: onSubmit,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                autoFocus: true,
                                                value: value,
                                                onChange: (e)=>setValue(e.target.value),
                                                id: "value",
                                                disabled: typing,
                                                autoComplete: "off",
                                                className: "block w-full resize-none rounded-xl border-none bg-input p-2 pl-5 pr-20 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 dark:bg-dark dark:text-white dark:placeholder-white[0.4] dark:focus:ring-blue-600 sm:text-base",
                                                placeholder: "Enter your prompt"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                onClick: ()=>onSubmit(),
                                                disabled: typing || (value === "" ? true : false),
                                                className: `absolute bottom-1 right-2.5 rounded-lg bg-primary ${value === "" && "bg-icon-gray"} px-4 py-2 text-white`,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    viewBox: "0 0 16 16",
                                                    fill: "none",
                                                    className: "h-4 w-4 m-1 md:m-0",
                                                    strokeWidth: "2",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M.5 1.163A1 1 0 0 1 1.97.28l12.868 6.837a1 1 0 0 1 0 1.766L1.969 15.72A1 1 0 0 1 .5 14.836V10.33a1 1 0 0 1 .816-.983L8.5 8 1.316 6.653A1 1 0 0 1 .5 5.67V1.163Z",
                                                        fill: "currentColor"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex lg:hidden h-full w-full flex-col",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        ref: mobileMessageContainerRef,
                        className: "flex-1 mb-12 space-y-6 p-4 text-sm sm:text-base",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-10"
                            }),
                            list && list.length > 0 && list.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        item?.user ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "mr-2 h-8 w-8 rounded-full",
                                                    src: "/AI.jpg",
                                                    alt: "img"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex rounded-b-xl text-sm text-secondary dark:text-white rounded-tr-xl bg-sky-chat p-4 dark:bg-slate-chat sm:max-w-md md:max-w-2xl",
                                                    children: !isPreview && index + 1 === list.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((typewriter_effect__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        options: {
                                                            delay: 20
                                                        },
                                                        onInit: (typewriter)=>{
                                                            typewriter.typeString(item?.text).pauseFor(2500).callFunction(()=>{
                                                                messageEl.current?.scrollIntoView({
                                                                    behavior: "smooth"
                                                                });
                                                            }).start();
                                                        }
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm text-secondary dark:text-white",
                                                        children: item?.text
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "ml-2 mt-1 flex flex-col-reverse gap-2 text-slate-500 sm:flex-row",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "hover:text-primary text-secondary dark:text-secondary dark:hover:text-primary",
                                                        type: "button",
                                                        onClick: ()=>navigator.clipboard.writeText(item?.text),
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            className: "h-5 w-5",
                                                            viewBox: "0 0 24 24",
                                                            strokeWidth: "2",
                                                            stroke: "currentColor",
                                                            fill: "none",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    stroke: "none",
                                                                    d: "M0 0h24v24H0z",
                                                                    fill: "none"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    d: "M8 8m0 2a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2z"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    d: "M16 8v-2a2 2 0 0 0 -2 -2h-8a2 2 0 0 0 -2 2v8a2 2 0 0 0 2 2h2"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }, index) : !item?.user && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-row-reverse items-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "ml-2 h-8 w-8 rounded-full",
                                                    src: "https://dummyimage.com/128x128/354ea1/ffffff&text=G"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex rounded-b-xl rounded-tl-xl bg-sky-chat p-4 dark:bg-slate-chat sm:min-h-0 sm:max-w-md md:max-w-2xl",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-sm text-secondary dark:text-white",
                                                        children: item?.text
                                                    })
                                                })
                                            ]
                                        }, index),
                                        typing && list.length == index + 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    className: "mr-2 h-8 w-8 rounded-full",
                                                    src: "/AI.jpg",
                                                    alt: "img"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: "/typing.gif",
                                                    className: "w-10",
                                                    alt: "typing"
                                                })
                                            ]
                                        }, index)
                                    ]
                                })),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: messageEl
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "fixed bottom-0 py-2 px-4 pb-4 w-[-webkit-fill-available] bg-white dark:bg-black",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: "relative",
                            onSubmit: onSubmit,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    autoFocus: true,
                                    value: value,
                                    onChange: (e)=>setValue(e.target.value),
                                    id: "value",
                                    disabled: typing,
                                    className: "block w-full resize-none rounded-xl border-none bg-input p-2 py-3 pl-5 pr-20 text-sm text-secondary focus:outline-none focus:ring-2 focus:ring-blue-600 dark:bg-dark dark:text-white dark:placeholder-white[0.4] dark:focus:ring-blue-600 sm:text-base",
                                    placeholder: "Enter your prompt",
                                    autoComplete: "off"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "submit",
                                    onClick: ()=>onSubmit(),
                                    disabled: typing || (value === "" ? true : false),
                                    className: `absolute bottom-1.5 right-2.5 rounded-lg bg-primary ${value === "" && "bg-icon-gray"} px-3 py-1 text-white`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        viewBox: "0 0 16 16",
                                        fill: "none",
                                        className: "h-4 w-4 m-1 md:m-0",
                                        strokeWidth: "2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M.5 1.163A1 1 0 0 1 1.97.28l12.868 6.837a1 1 0 0 1 0 1.766L1.969 15.72A1 1 0 0 1 .5 14.836V10.33a1 1 0 0 1 .816-.983L8.5 8 1.316 6.653A1 1 0 0 1 .5 5.67V1.163Z",
                                            fill: "currentColor"
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [866,602], () => (__webpack_exec__(59006)));
module.exports = __webpack_exports__;

})();